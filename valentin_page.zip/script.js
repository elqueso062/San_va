const yesBtn = document.getElementById("yesBtn");
const noBtn = document.getElementById("noBtn");

const phrases = ["Sí mi amor", "Sí mi vida", "Chi", "Sí porque eres el amor de mi vida"];
let phraseIndex = 0;

yesBtn.addEventListener("click", () => {
    alert("Sabía que dirías que sí, mi amor");
});

noBtn.addEventListener("click", () => {
    phraseIndex = (phraseIndex + 1) % phrases.length;
    yesBtn.textContent = phrases[phraseIndex];
    yesBtn.style.fontSize = `${parseInt(window.getComputedStyle(yesBtn).fontSize) + 5}px`;
});
